#include <iostream>
#include "quanly.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	QuanLy instance1;
	instance1.display();
	//Nguoi ng("N","m","0");
	return 0;
}
